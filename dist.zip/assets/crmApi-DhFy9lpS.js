const g="/api";function b(){const e=localStorage.getItem("neuorzin_jwt_token");if(e)return e;if(localStorage.getItem("neuorzin_admin_auth")==="true"){const a="neuorzin_admin_local_token_super_admin";try{localStorage.setItem("neuorzin_jwt_token",a)}catch{}return a}return""}async function o(e,t={}){const a=b(),n={"Content-Type":"application/json",...a?{Authorization:`Bearer ${a}`}:{},...t.headers};try{const r=await fetch(`${g}${e}`,{...t,headers:n});if(!(r.headers.get("content-type")||"").includes("application/json"))throw new Error(`Backend API route '${e}' not responding with JSON. (Status: ${r.status})`);if(!r.ok){const c=await r.json().catch(()=>({}));throw new Error(c.error||`HTTP ${r.status}: ${r.statusText}`)}return await r.json()}catch(r){throw console.warn(`[CRM API] ${e} fetch error:`,r.message),r}}function $(e,t,a){const n=e==="INVOICE",r=n?"TAX INVOICE":"GST COMMERCIAL ESTIMATE / QUOTATION",i=n?"#059669":"#0070ba",c=a?.customer_name||a?.company||"Valued Client Enterprise",s=Array.isArray(a?.items)?a.items:[],l=Number(a?.subtotal||Number(a?.total_amount||0)/1.18),u=Number(a?.gst_amount||l*.18),y=Number(a?.total_amount||l+u),f=Number(a?.paid_amount||0),p=Math.max(0,y-f),h=`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${r} - ${t}</title>
        <meta charset="utf-8" />
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 40px; color: #1e293b; }
          .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; }
          .logo { font-size: 24px; font-weight: 900; color: ${i}; letter-spacing: -0.5px; }
          .sub { font-size: 12px; color: #64748b; margin-top: 4px; }
          .title { font-size: 16px; font-weight: 800; margin: 24px 0 16px; color: #0f172a; text-transform: uppercase; }
          .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; font-size: 13px; }
          .meta-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 13px; }
          th { background: #f1f5f9; text-align: left; padding: 10px 14px; font-weight: 700; border-bottom: 1px solid #cbd5e1; }
          td { padding: 12px 14px; border-bottom: 1px solid #e2e8f0; }
          .totals { margin-left: auto; width: 320px; margin-bottom: 30px; font-size: 14px; }
          .totals-row { display: flex; justify-content: space-between; padding: 6px 0; }
          .grand-total { border-top: 2px solid ${i}; font-size: 16px; font-weight: 900; color: ${i}; padding-top: 10px; }
          .footer { font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 16px; margin-top: 40px; }
          @media print { body { margin: 0; } .no-print { display: none; } }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 20px; text-align: right;">
          <button onclick="window.print()" style="padding: 10px 20px; background: ${i}; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Print / Save as PDF</button>
        </div>
        <div class="header">
          <div>
            <div class="logo">NEUORZIN TECH LABS</div>
            <div class="sub">Enterprise Software & Autonomous AI Solutions Provider</div>
            <div class="sub">GSTIN: 36AAACN1234F1Z8 | SAC: 998313 | info@neuorzin.com</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 18px; font-weight: bold; color: ${i};">${t}</div>
            <div class="sub">Date: ${new Date().toLocaleDateString("en-IN")}</div>
            <div class="sub">Status: <strong>${a?.status||(n?"Pending":"Issued")}</strong></div>
          </div>
        </div>

        <div class="title">${r}</div>

        <div class="meta-grid">
          <div class="meta-box">
            <strong style="color: #64748b; font-size: 11px; text-transform: uppercase;">Billed / Prepared To</strong>
            <div style="font-size: 15px; font-weight: bold; margin: 4px 0;">${c}</div>
            <div style="color: #64748b;">Attn: ${a?.customer_name||"Management"}</div>
            <div style="color: #64748b;">Service: ${a?.service_title||"Enterprise Engineering Implementation"}</div>
          </div>
          <div class="meta-box">
            <strong style="color: #64748b; font-size: 11px; text-transform: uppercase;">Commercial Terms</strong>
            <div style="margin: 4px 0;">Due Date: <strong>${a?.due_date||a?.valid_until||"Net 15 Days"}</strong></div>
            <div style="color: #64748b;">Currency: INR (₹) Indian Rupee</div>
            <div style="color: #64748b;">SAC/HSN Code: 998313 (IT Services)</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>Description / Scope Deliverable</th>
              <th style="width: 60px;">Qty</th>
              <th style="width: 120px; text-align: right;">Rate (₹)</th>
              <th style="width: 140px; text-align: right;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${s.length>0?s.map(d=>`
              <tr>
                <td><strong>${d.description||d.name||"Deliverable"}</strong></td>
                <td>${d.qty||1}</td>
                <td style="text-align: right;">₹${Number(d.rate||d.amount||0).toLocaleString("en-IN")}</td>
                <td style="text-align: right;">₹${Number(d.amount||Number(d.rate||0)*Number(d.qty||1)).toLocaleString("en-IN")}</td>
              </tr>
            `).join(""):`
              <tr>
                <td><strong>${a?.service_title||"Enterprise Software Architecture & Custom Engineering"}</strong></td>
                <td>1</td>
                <td style="text-align: right;">₹${l.toLocaleString("en-IN")}</td>
                <td style="text-align: right;">₹${l.toLocaleString("en-IN")}</td>
              </tr>
            `}
          </tbody>
        </table>

        <div class="totals">
          <div class="totals-row"><span>Subtotal (Taxable):</span><strong>₹${l.toLocaleString("en-IN")}</strong></div>
          <div class="totals-row"><span>GST (18% Integrated IGST):</span><span>₹${u.toLocaleString("en-IN")}</span></div>
          <div class="totals-row grand-total"><span>Total Value:</span><span>₹${y.toLocaleString("en-IN")}</span></div>
          ${n?`
            <div class="totals-row" style="color: #059669; margin-top: 6px;"><span>Amount Paid:</span><strong>₹${f.toLocaleString("en-IN")}</strong></div>
            <div class="totals-row" style="color: ${p>0?"#dc2626":"#059669"}; font-weight: bold;"><span>Balance Due:</span><strong>₹${p.toLocaleString("en-IN")}</strong></div>
          `:""}
        </div>

        <div class="footer">
          <strong>Bank Remittance:</strong> NEUORZIN TECH LABS PVT LTD | HDFC Bank A/C: 50200088991122 | IFSC: HDFC0001234 | UPI: neuorzin@hdfcbank<br/>
          <em>This is a computer-generated GST invoice/quotation. No physical signature required.</em>
        </div>
      </body>
    </html>
  `,m=window.open("","_blank");m&&(m.document.write(h),m.document.close())}const P={checkHealth:async()=>{try{const e=await fetch(`${g}/health`,{method:"GET"}),t=e.headers.get("content-type")||"";return e.ok&&t.includes("application/json")}catch{return!1}},login:async(e,t)=>{const a=await o("/auth/login",{method:"POST",body:JSON.stringify({email:e,password:t})});return a.token&&localStorage.setItem("neuorzin_jwt_token",a.token),a},getMe:()=>o("/auth/me"),getUsers:()=>o("/users"),getLeads:(e={})=>{const t=new URLSearchParams(e).toString();return o(`/leads${t?`?${t}`:""}`)},getLeadById:e=>o(`/leads/${e}`),createLead:e=>o("/leads",{method:"POST",body:JSON.stringify(e)}),updateLead:(e,t)=>o(`/leads/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteLead:e=>o(`/leads/${e}`,{method:"DELETE"}),convertLead:(e,t)=>o(`/leads/${e}/convert`,{method:"POST",body:JSON.stringify({deal_amount:t})}),getActivities:(e={})=>{const t=new URLSearchParams(e).toString();return o(`/followups${t?`?${t}`:""}`)},createActivity:e=>o("/followups",{method:"POST",body:JSON.stringify(e)}),updateActivity:(e,t)=>o(`/followups/${e}`,{method:"PUT",body:JSON.stringify(t)}),getPipelines:()=>o("/pipelines"),getDeals:(e={})=>{const t=new URLSearchParams(e).toString();return o(`/deals${t?`?${t}`:""}`)},createDeal:e=>o("/deals",{method:"POST",body:JSON.stringify(e)}),updateDeal:(e,t)=>o(`/deals/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteDeal:e=>o(`/deals/${e}`,{method:"DELETE"}),getQuotations:()=>o("/quotations"),createQuotation:e=>o("/quotations",{method:"POST",body:JSON.stringify(e)}),updateQuotation:(e,t)=>o(`/quotations/${e}`,{method:"PUT",body:JSON.stringify(t)}),updateQuotationStatus:(e,t)=>o(`/quotations/${e}/status`,{method:"PUT",body:JSON.stringify({status:t})}),deleteQuotation:e=>o(`/quotations/${e}`,{method:"DELETE"}),getQuotationPdfUrl:e=>`${g}/quotations/${e}/pdf`,downloadQuotationPdf:async(e,t="Quotation",a=null)=>{try{const n=b(),r=await fetch(`${g}/quotations/${e}/pdf`,{headers:n?{Authorization:`Bearer ${n}`}:{}});if(r.ok){const i=await r.blob();if(i&&i.size>0){const c=window.URL.createObjectURL(i),s=document.createElement("a");return s.href=c,s.download=`Quotation_${t}.pdf`,document.body.appendChild(s),s.click(),document.body.removeChild(s),window.URL.revokeObjectURL(c),!0}}}catch(n){console.warn("Backend PDF download notice, generating printable document:",n)}return $("QUOTATION",t,a),!0},getInvoices:()=>o("/invoices"),createInvoice:e=>o("/invoices",{method:"POST",body:JSON.stringify(e)}),updateInvoice:(e,t)=>o(`/invoices/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteInvoice:e=>o(`/invoices/${e}`,{method:"DELETE"}),getInvoicePdfUrl:e=>`${g}/invoices/${e}/pdf`,downloadInvoicePdf:async(e,t="Invoice",a=null)=>{try{const n=b(),r=await fetch(`${g}/invoices/${e}/pdf`,{headers:n?{Authorization:`Bearer ${n}`}:{}});if(r.ok){const i=await r.blob();if(i&&i.size>0){const c=window.URL.createObjectURL(i),s=document.createElement("a");return s.href=c,s.download=`Invoice_${t}.pdf`,document.body.appendChild(s),s.click(),document.body.removeChild(s),window.URL.revokeObjectURL(c),!0}}}catch(n){console.warn("Backend PDF download notice, generating printable document:",n)}return $("INVOICE",t,a),!0},recordPayment:e=>o("/invoices/payments",{method:"POST",body:JSON.stringify(e)}),getProjects:()=>o("/projects"),getProjectById:e=>o(`/projects/${e}`),createProject:e=>o("/projects",{method:"POST",body:JSON.stringify(e)}),updateProject:(e,t)=>o(`/projects/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteProject:e=>o(`/projects/${e}`,{method:"DELETE"}),getTasks:(e={})=>{const t=new URLSearchParams(e).toString();return o(`/tasks${t?`?${t}`:""}`)},createTask:e=>o("/tasks",{method:"POST",body:JSON.stringify(e)}),updateTask:(e,t)=>o(`/tasks/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteTask:e=>o(`/tasks/${e}`,{method:"DELETE"}),logTimesheet:e=>o("/tasks/timesheets",{method:"POST",body:JSON.stringify(e)}),getWhatsAppMessages:(e={})=>{const t=new URLSearchParams(e).toString();return o(`/whatsapp/messages${t?`?${t}`:""}`)},sendWhatsAppMessage:e=>o("/whatsapp/send",{method:"POST",body:JSON.stringify(e)}),deleteWhatsAppMessage:e=>o(`/whatsapp/messages/${e}`,{method:"DELETE"}),getCampaigns:()=>o("/marketing/campaigns"),createCampaign:e=>o("/marketing/campaigns",{method:"POST",body:JSON.stringify(e)}),updateCampaign:(e,t)=>o(`/marketing/campaigns/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteCampaign:e=>o(`/marketing/campaigns/${e}`,{method:"DELETE"}),getDashboardMetrics:()=>o("/reports/dashboard"),globalSearch:e=>o(`/search?q=${encodeURIComponent(e)}`),getAuditLogs:()=>o("/audit-logs"),getNotifications:async(e={})=>{const t=new URLSearchParams(e).toString(),a=await o(`/notifications${t?`?${t}`:""}`);return Array.isArray(a)?a:a?.notifications||[]},markNotificationRead:e=>o(`/notifications/${e}/read`,{method:"PUT"}),markAllNotificationsRead:()=>o("/notifications/read-all",{method:"PUT"}),deleteNotification:e=>o(`/notifications/${e}`,{method:"DELETE"}),getBlogs:(e={})=>{const t=new URLSearchParams(e).toString();return o(`/blogs${t?`?${t}`:""}`)},getBlogById:e=>o(`/blogs/${e}`),createBlog:e=>o("/blogs",{method:"POST",body:JSON.stringify(e)}),updateBlog:(e,t)=>o(`/blogs/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteBlog:e=>o(`/blogs/${e}`,{method:"DELETE"}),publishBlog:e=>o(`/blogs/${e}/publish`,{method:"POST"}),unpublishBlog:e=>o(`/blogs/${e}/unpublish`,{method:"POST"}),getCategories:()=>o("/blog-categories"),createCategory:e=>o("/blog-categories",{method:"POST",body:JSON.stringify(e)}),deleteCategory:e=>o(`/blog-categories/${e}`,{method:"DELETE"}),getTags:()=>o("/blog-tags"),createTag:e=>o("/blog-tags",{method:"POST",body:JSON.stringify(e)}),getAiConfig:async()=>{try{const n=await o("/admin/ai-config");if(n&&n.has_key)return n}catch(n){console.warn("Backend AI config notice, checking local cache:",n.message)}const e=localStorage.getItem("neuorzin_gemini_api_key")||"",t=localStorage.getItem("neuorzin_ai_config"),a=t?JSON.parse(t):{};return{has_key:!!(e||a.has_key),masked_key:e?`${e.slice(0,6)}...${e.slice(-4)}`:a.masked_key||"",model:a.model||"gemini-1.5-flash",temperature:a.temperature||.7,max_tokens:a.max_tokens||4096,system_context:a.system_context||"You are a high-level enterprise technology journalist and software architect at NeuOrzin. Write well-structured, factual, SEO-rich insights with clear headers and bullet points."}},saveAiConfig:async e=>{try{e.api_key&&localStorage.setItem("neuorzin_gemini_api_key",e.api_key),localStorage.setItem("neuorzin_ai_config",JSON.stringify({...e,has_key:!!(e.api_key||localStorage.getItem("neuorzin_gemini_api_key")),masked_key:e.api_key?`${e.api_key.slice(0,6)}...${e.api_key.slice(-4)}`:void 0}))}catch{}try{return await o("/admin/ai-config",{method:"PUT",body:JSON.stringify(e)})}catch(t){return console.warn("Backend AI config sync notice (saved to local secure storage):",t.message),{success:!0,message:"Saved to local secure storage"}}},testAiConfig:async e=>{const t=e||localStorage.getItem("neuorzin_gemini_api_key")||"";try{return await o("/admin/ai-config/test",{method:"POST",body:JSON.stringify({gemini_api_key:t})})}catch{if(!t)throw new Error("Please enter a Gemini API Key to test.");try{const n=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${encodeURIComponent(t)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:"Hello! Respond with: OK"}]}]})}),r=await n.json();if(n.ok&&r.candidates?.[0]?.content)return{success:!0,message:"Google Gemini API key verified and working perfectly!"};throw new Error(r.error?.message||"Invalid API key or quota exceeded")}catch(n){throw new Error(n.message||"Failed to verify Gemini API key")}}},generateBlogWithGemini:async e=>{try{return await o("/blogs/generate",{method:"POST",body:JSON.stringify(e)})}catch{const a=localStorage.getItem("neuorzin_gemini_api_key")||"";if(!a)throw new Error("Gemini API Key is not configured. Please go to Admin Settings -> Gemini AI Engine and enter your API Key.");const{topic:n="Enterprise Technology Innovation",tone:r="Authoritative & Practical",length:i="Comprehensive (1500+ words)",category:c="Cloud Platform",keywords:s="",audience:l="Enterprise Leaders",instructions:u=""}=e,y=`You are a world-class principal technology strategist, revenue engineer, and editorial writer at NeuOrzin (neuorzin.com).
Write an in-depth, authentic, highly engaging article on the topic: '${n}'.
Tone: ${r}.
Target Audience: ${l}.
Length Category: ${i}.
Category: ${c}.
Keywords to weave naturally: ${s}.
Additional Guidelines: ${u}.

You MUST return your response as a valid JSON object matching this exact schema:
{
  "title": "Catchy, high-authority headline with strong editorial value",
  "slug": "seo-friendly-url-slug-all-lowercase-hyphens",
  "excerpt": "1-2 punchy sentences summarizing the core problem and high-intent takeaway",
  "intro": "Engaging opening paragraph establishing empathy with decision-makers",
  "readTime": "6 min read",
  "tags": ["Tag 1", "Tag 2", "Tag 3", "Tag 4", "Tag 5"],
  "category": "${c}",
  "sections": [
    {
      "heading": "1. Section Heading",
      "paragraphs": ["Paragraph 1...", "Paragraph 2..."],
      "callout": "A bold, memorable pull-quote or takeaway sentence."
    },
    {
      "heading": "2. Section Heading",
      "paragraphs": ["Paragraph 1...", "Paragraph 2..."],
      "list": ["Bullet point 1 with actionable insight", "Bullet point 2 with concrete takeaway", "Bullet point 3 with architectural wisdom"]
    },
    {
      "heading": "3. Section Heading",
      "paragraphs": ["Paragraph 1...", "Paragraph 2..."]
    },
    {
      "heading": "4. Section Heading",
      "paragraphs": ["Paragraph 1...", "Paragraph 2..."]
    }
  ],
  "conclusion": "Powerful concluding paragraph leaving executive readers with clarity on immediate next steps.",
  "seo_title": "SEO Meta Title (under 60 chars) | NeuOrzin",
  "seo_description": "SEO Meta Description (140-160 chars) designed for high click-through rate.",
  "seo_keywords": "comma, separated, high, intent, keywords"
}

Return ONLY the raw JSON object without markdown fences or extraneous text.`,f=["gemini-1.5-flash-latest","gemini-2.0-flash","gemini-1.5-flash-8b","gemini-1.5-pro-latest","gemini-1.5-pro","gemini-pro"];let p=null,h="Gemini generation failed";for(const m of f)try{const d=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(m)}:generateContent?key=${encodeURIComponent(a)}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:y}]}],generationConfig:{temperature:.7,responseMimeType:"application/json"}})}),w=await d.json();if(d.ok&&w.candidates?.[0]?.content?.parts?.[0]?.text){const T=w.candidates[0].content.parts[0].text.replace(/^```json\s*/i,"").replace(/```$/i,"").trim(),S=JSON.parse(T);if(S&&S.title){p=S;break}}else h=w.error?.message||`HTTP ${d.status}`}catch(d){h=d.message}if(p)return{success:!0,data:p};throw new Error(h)}},getUserById:e=>o(`/users/${e}`),createUser:e=>o("/users",{method:"POST",body:JSON.stringify(e)}),updateUser:(e,t)=>o(`/users/${e}`,{method:"PUT",body:JSON.stringify(t)}),deleteUser:e=>o(`/users/${e}`,{method:"DELETE"}),updateUserRole:(e,t)=>o(`/users/${e}/role`,{method:"PATCH",body:JSON.stringify({role:t})}),updateUserStatus:(e,t)=>o(`/users/${e}/status`,{method:"PATCH",body:JSON.stringify({status:t})}),updateProfile:e=>o("/users/profile",{method:"PUT",body:JSON.stringify(e)}),forgotPassword:e=>o("/auth/forgot-password",{method:"POST",body:JSON.stringify({email:e})}),resetPassword:(e,t)=>o("/auth/reset-password",{method:"POST",body:JSON.stringify({token:e,new_password:t})}),changePassword:(e,t,a)=>o("/auth/change-password",{method:"POST",body:JSON.stringify({user_id:e,current_password:t,new_password:a})}),uploadImage:async e=>{const t=new FormData;t.append("file",e);const a=b(),n=await fetch(`${g}/upload`,{method:"POST",headers:a?{Authorization:`Bearer ${a}`}:{},body:t});if(!n.ok){const r=await n.json().catch(()=>({}));throw new Error(r.error||"Failed to upload image")}return await n.json()}};export{P as c};
