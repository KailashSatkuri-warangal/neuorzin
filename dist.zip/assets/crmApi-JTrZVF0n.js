const l="/api";function p(){return localStorage.getItem("neuorzin_jwt_token")||""}async function e(t,o={}){const n=p(),i={"Content-Type":"application/json",...n?{Authorization:`Bearer ${n}`}:{},...o.headers};try{const s=await fetch(`${l}${t}`,{...o,headers:i});if(!(s.headers.get("content-type")||"").includes("application/json"))throw new Error(`Backend API route '${t}' not responding with JSON. (Status: ${s.status})`);if(!s.ok){const d=await s.json().catch(()=>({}));throw new Error(d.error||`HTTP ${s.status}: ${s.statusText}`)}return await s.json()}catch(s){throw console.warn(`[CRM API] ${t} fetch error:`,s.message),s}}function f(t,o,n){const i=t==="INVOICE",s=i?"TAX INVOICE":"GST COMMERCIAL ESTIMATE / QUOTATION",a=i?"#059669":"#0070ba",d=n?.customer_name||n?.company||"Valued Client Enterprise",r=Array.isArray(n?.items)?n.items:[],g=Number(n?.subtotal||Number(n?.total_amount||0)/1.18),u=Number(n?.gst_amount||g*.18),h=Number(n?.total_amount||g+u),y=Number(n?.paid_amount||0),b=Math.max(0,h-y),S=`
    <!DOCTYPE html>
    <html>
      <head>
        <title>${s} - ${o}</title>
        <meta charset="utf-8" />
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; margin: 40px; color: #1e293b; }
          .header { display: flex; justify-content: space-between; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; }
          .logo { font-size: 24px; font-weight: 900; color: ${a}; letter-spacing: -0.5px; }
          .sub { font-size: 12px; color: #64748b; margin-top: 4px; }
          .title { font-size: 16px; font-weight: 800; margin: 24px 0 16px; color: #0f172a; text-transform: uppercase; }
          .meta-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; font-size: 13px; }
          .meta-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; }
          table { width: 100%; border-collapse: collapse; margin-bottom: 24px; font-size: 13px; }
          th { background: #f1f5f9; text-align: left; padding: 10px 14px; font-weight: 700; border-bottom: 1px solid #cbd5e1; }
          td { padding: 12px 14px; border-bottom: 1px solid #e2e8f0; }
          .totals { margin-left: auto; width: 320px; margin-bottom: 30px; font-size: 14px; }
          .totals-row { display: flex; justify-content: space-between; padding: 6px 0; }
          .grand-total { border-top: 2px solid ${a}; font-size: 16px; font-weight: 900; color: ${a}; padding-top: 10px; }
          .footer { font-size: 11px; color: #64748b; border-top: 1px solid #e2e8f0; padding-top: 16px; margin-top: 40px; }
          @media print { body { margin: 0; } .no-print { display: none; } }
        </style>
      </head>
      <body>
        <div class="no-print" style="margin-bottom: 20px; text-align: right;">
          <button onclick="window.print()" style="padding: 10px 20px; background: ${a}; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">Print / Save as PDF</button>
        </div>
        <div class="header">
          <div>
            <div class="logo">NEUORZIN TECH LABS</div>
            <div class="sub">Enterprise Software & Autonomous AI Solutions Provider</div>
            <div class="sub">GSTIN: 36AAACN1234F1Z8 | SAC: 998313 | info@neuorzin.com</div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 18px; font-weight: bold; color: ${a};">${o}</div>
            <div class="sub">Date: ${new Date().toLocaleDateString("en-IN")}</div>
            <div class="sub">Status: <strong>${n?.status||(i?"Pending":"Issued")}</strong></div>
          </div>
        </div>

        <div class="title">${s}</div>

        <div class="meta-grid">
          <div class="meta-box">
            <strong style="color: #64748b; font-size: 11px; text-transform: uppercase;">Billed / Prepared To</strong>
            <div style="font-size: 15px; font-weight: bold; margin: 4px 0;">${d}</div>
            <div style="color: #64748b;">Attn: ${n?.customer_name||"Management"}</div>
            <div style="color: #64748b;">Service: ${n?.service_title||"Enterprise Engineering Implementation"}</div>
          </div>
          <div class="meta-box">
            <strong style="color: #64748b; font-size: 11px; text-transform: uppercase;">Commercial Terms</strong>
            <div style="margin: 4px 0;">Due Date: <strong>${n?.due_date||n?.valid_until||"Net 15 Days"}</strong></div>
            <div style="color: #64748b;">Currency: INR (₹) Indian Rupee</div>
            <div style="color: #64748b;">SAC/HSN Code: 998313 (IT Services)</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>Description / Scope Deliverable</th>
              <th style="width: 60px;">Qty</th>
              <th style="width: 120px; text-align: right;">Rate (₹)</th>
              <th style="width: 140px; text-align: right;">Amount (₹)</th>
            </tr>
          </thead>
          <tbody>
            ${r.length>0?r.map(c=>`
              <tr>
                <td><strong>${c.description||c.name||"Deliverable"}</strong></td>
                <td>${c.qty||1}</td>
                <td style="text-align: right;">₹${Number(c.rate||c.amount||0).toLocaleString("en-IN")}</td>
                <td style="text-align: right;">₹${Number(c.amount||Number(c.rate||0)*Number(c.qty||1)).toLocaleString("en-IN")}</td>
              </tr>
            `).join(""):`
              <tr>
                <td><strong>${n?.service_title||"Enterprise Software Architecture & Custom Engineering"}</strong></td>
                <td>1</td>
                <td style="text-align: right;">₹${g.toLocaleString("en-IN")}</td>
                <td style="text-align: right;">₹${g.toLocaleString("en-IN")}</td>
              </tr>
            `}
          </tbody>
        </table>

        <div class="totals">
          <div class="totals-row"><span>Subtotal (Taxable):</span><strong>₹${g.toLocaleString("en-IN")}</strong></div>
          <div class="totals-row"><span>GST (18% Integrated IGST):</span><span>₹${u.toLocaleString("en-IN")}</span></div>
          <div class="totals-row grand-total"><span>Total Value:</span><span>₹${h.toLocaleString("en-IN")}</span></div>
          ${i?`
            <div class="totals-row" style="color: #059669; margin-top: 6px;"><span>Amount Paid:</span><strong>₹${y.toLocaleString("en-IN")}</strong></div>
            <div class="totals-row" style="color: ${b>0?"#dc2626":"#059669"}; font-weight: bold;"><span>Balance Due:</span><strong>₹${b.toLocaleString("en-IN")}</strong></div>
          `:""}
        </div>

        <div class="footer">
          <strong>Bank Remittance:</strong> NEUORZIN TECH LABS PVT LTD | HDFC Bank A/C: 50200088991122 | IFSC: HDFC0001234 | UPI: neuorzin@hdfcbank<br/>
          <em>This is a computer-generated GST invoice/quotation. No physical signature required.</em>
        </div>
      </body>
    </html>
  `,m=window.open("","_blank");m&&(m.document.write(S),m.document.close())}const $={checkHealth:async()=>{try{const t=await fetch(`${l}/health`,{method:"GET"}),o=t.headers.get("content-type")||"";return t.ok&&o.includes("application/json")}catch{return!1}},login:async(t,o)=>{const n=await e("/auth/login",{method:"POST",body:JSON.stringify({email:t,password:o})});return n.token&&localStorage.setItem("neuorzin_jwt_token",n.token),n},getMe:()=>e("/auth/me"),getUsers:()=>e("/users"),getLeads:(t={})=>{const o=new URLSearchParams(t).toString();return e(`/leads${o?`?${o}`:""}`)},getLeadById:t=>e(`/leads/${t}`),createLead:t=>e("/leads",{method:"POST",body:JSON.stringify(t)}),updateLead:(t,o)=>e(`/leads/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteLead:t=>e(`/leads/${t}`,{method:"DELETE"}),convertLead:(t,o)=>e(`/leads/${t}/convert`,{method:"POST",body:JSON.stringify({deal_amount:o})}),getActivities:(t={})=>{const o=new URLSearchParams(t).toString();return e(`/followups${o?`?${o}`:""}`)},createActivity:t=>e("/followups",{method:"POST",body:JSON.stringify(t)}),updateActivity:(t,o)=>e(`/followups/${t}`,{method:"PUT",body:JSON.stringify(o)}),getPipelines:()=>e("/pipelines"),getDeals:(t={})=>{const o=new URLSearchParams(t).toString();return e(`/deals${o?`?${o}`:""}`)},createDeal:t=>e("/deals",{method:"POST",body:JSON.stringify(t)}),updateDeal:(t,o)=>e(`/deals/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteDeal:t=>e(`/deals/${t}`,{method:"DELETE"}),getQuotations:()=>e("/quotations"),createQuotation:t=>e("/quotations",{method:"POST",body:JSON.stringify(t)}),updateQuotation:(t,o)=>e(`/quotations/${t}`,{method:"PUT",body:JSON.stringify(o)}),updateQuotationStatus:(t,o)=>e(`/quotations/${t}/status`,{method:"PUT",body:JSON.stringify({status:o})}),deleteQuotation:t=>e(`/quotations/${t}`,{method:"DELETE"}),getQuotationPdfUrl:t=>`${l}/quotations/${t}/pdf`,downloadQuotationPdf:async(t,o="Quotation",n=null)=>{try{const i=p(),s=await fetch(`${l}/quotations/${t}/pdf`,{headers:i?{Authorization:`Bearer ${i}`}:{}});if(s.ok){const a=await s.blob();if(a&&a.size>0){const d=window.URL.createObjectURL(a),r=document.createElement("a");return r.href=d,r.download=`Quotation_${o}.pdf`,document.body.appendChild(r),r.click(),document.body.removeChild(r),window.URL.revokeObjectURL(d),!0}}}catch(i){console.warn("Backend PDF download notice, generating printable document:",i)}return f("QUOTATION",o,n),!0},getInvoices:()=>e("/invoices"),createInvoice:t=>e("/invoices",{method:"POST",body:JSON.stringify(t)}),updateInvoice:(t,o)=>e(`/invoices/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteInvoice:t=>e(`/invoices/${t}`,{method:"DELETE"}),getInvoicePdfUrl:t=>`${l}/invoices/${t}/pdf`,downloadInvoicePdf:async(t,o="Invoice",n=null)=>{try{const i=p(),s=await fetch(`${l}/invoices/${t}/pdf`,{headers:i?{Authorization:`Bearer ${i}`}:{}});if(s.ok){const a=await s.blob();if(a&&a.size>0){const d=window.URL.createObjectURL(a),r=document.createElement("a");return r.href=d,r.download=`Invoice_${o}.pdf`,document.body.appendChild(r),r.click(),document.body.removeChild(r),window.URL.revokeObjectURL(d),!0}}}catch(i){console.warn("Backend PDF download notice, generating printable document:",i)}return f("INVOICE",o,n),!0},recordPayment:t=>e("/invoices/payments",{method:"POST",body:JSON.stringify(t)}),getProjects:()=>e("/projects"),getProjectById:t=>e(`/projects/${t}`),createProject:t=>e("/projects",{method:"POST",body:JSON.stringify(t)}),updateProject:(t,o)=>e(`/projects/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteProject:t=>e(`/projects/${t}`,{method:"DELETE"}),getTasks:(t={})=>{const o=new URLSearchParams(t).toString();return e(`/tasks${o?`?${o}`:""}`)},createTask:t=>e("/tasks",{method:"POST",body:JSON.stringify(t)}),updateTask:(t,o)=>e(`/tasks/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteTask:t=>e(`/tasks/${t}`,{method:"DELETE"}),logTimesheet:t=>e("/tasks/timesheets",{method:"POST",body:JSON.stringify(t)}),getWhatsAppMessages:(t={})=>{const o=new URLSearchParams(t).toString();return e(`/whatsapp/messages${o?`?${o}`:""}`)},sendWhatsAppMessage:t=>e("/whatsapp/send",{method:"POST",body:JSON.stringify(t)}),deleteWhatsAppMessage:t=>e(`/whatsapp/messages/${t}`,{method:"DELETE"}),getCampaigns:()=>e("/marketing/campaigns"),createCampaign:t=>e("/marketing/campaigns",{method:"POST",body:JSON.stringify(t)}),updateCampaign:(t,o)=>e(`/marketing/campaigns/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteCampaign:t=>e(`/marketing/campaigns/${t}`,{method:"DELETE"}),getDashboardMetrics:()=>e("/reports/dashboard"),globalSearch:t=>e(`/search?q=${encodeURIComponent(t)}`),getAuditLogs:()=>e("/audit-logs"),getNotifications:async(t={})=>{const o=new URLSearchParams(t).toString(),n=await e(`/notifications${o?`?${o}`:""}`);return Array.isArray(n)?n:n?.notifications||[]},markNotificationRead:t=>e(`/notifications/${t}/read`,{method:"PUT"}),markAllNotificationsRead:()=>e("/notifications/read-all",{method:"PUT"}),deleteNotification:t=>e(`/notifications/${t}`,{method:"DELETE"}),getBlogs:(t={})=>{const o=new URLSearchParams(t).toString();return e(`/blogs${o?`?${o}`:""}`)},getBlogById:t=>e(`/blogs/${t}`),createBlog:t=>e("/blogs",{method:"POST",body:JSON.stringify(t)}),updateBlog:(t,o)=>e(`/blogs/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteBlog:t=>e(`/blogs/${t}`,{method:"DELETE"}),publishBlog:t=>e(`/blogs/${t}/publish`,{method:"POST"}),unpublishBlog:t=>e(`/blogs/${t}/unpublish`,{method:"POST"}),getCategories:()=>e("/blog-categories"),createCategory:t=>e("/blog-categories",{method:"POST",body:JSON.stringify(t)}),deleteCategory:t=>e(`/blog-categories/${t}`,{method:"DELETE"}),getTags:()=>e("/blog-tags"),createTag:t=>e("/blog-tags",{method:"POST",body:JSON.stringify(t)}),getAiConfig:()=>e("/admin/ai-config"),saveAiConfig:t=>e("/admin/ai-config",{method:"PUT",body:JSON.stringify(t)}),testAiConfig:t=>e("/admin/ai-config/test",{method:"POST",body:JSON.stringify(t||{})}),generateBlogWithGemini:t=>e("/blogs/generate",{method:"POST",body:JSON.stringify(t)}),getUserById:t=>e(`/users/${t}`),createUser:t=>e("/users",{method:"POST",body:JSON.stringify(t)}),updateUser:(t,o)=>e(`/users/${t}`,{method:"PUT",body:JSON.stringify(o)}),deleteUser:t=>e(`/users/${t}`,{method:"DELETE"}),updateUserRole:(t,o)=>e(`/users/${t}/role`,{method:"PATCH",body:JSON.stringify({role:o})}),updateUserStatus:(t,o)=>e(`/users/${t}/status`,{method:"PATCH",body:JSON.stringify({status:o})}),updateProfile:t=>e("/users/profile",{method:"PUT",body:JSON.stringify(t)}),forgotPassword:t=>e("/auth/forgot-password",{method:"POST",body:JSON.stringify({email:t})}),resetPassword:(t,o)=>e("/auth/reset-password",{method:"POST",body:JSON.stringify({token:t,new_password:o})}),changePassword:(t,o,n)=>e("/auth/change-password",{method:"POST",body:JSON.stringify({user_id:t,current_password:o,new_password:n})}),uploadImage:async t=>{const o=new FormData;o.append("file",t);const n=p(),i=await fetch(`${l}/upload`,{method:"POST",headers:n?{Authorization:`Bearer ${n}`}:{},body:o});if(!i.ok){const s=await i.json().catch(()=>({}));throw new Error(s.error||"Failed to upload image")}return await i.json()}};export{$ as c};
